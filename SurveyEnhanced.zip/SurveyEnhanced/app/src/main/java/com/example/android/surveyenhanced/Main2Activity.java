package com.example.android.surveyenhanced;


import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    EditText textName;
    EditText textLAN;
    String name;
    String inputLAN;
    String LAN = "local area network";
    String question1SelectedText = "";
    int question2RadioButtonID;
    String question2SelectedText;
    int question3RadioButtonID;
    String question3SelectedText;
    int question4RadioButtonID;
    String question4SelectedText;
    int question5RadioButtonID;
    String question5SelectedText;
    int question6RadioButtonID;
    String question6SelectedText;
    String results;
    int score = 0;
    boolean checkbox1 = false;
    boolean checkbox2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    /**
     * coding to capture the user selection in an array for the checkbox question
     */
    public void selectItem(View view) {
        /*ArrayList<String> question1Selection = new ArrayList<String>();
        boolean checked = ((CheckBox) view).isChecked();

        switch (view.getId()) {
            case R.id.question1CheckBox1:
                if (checked) {
                    question1Selection.add("192.168.0.0 - 192.168.255.255, ");
                    checkbox1 = true;
                } else {
                    question1Selection.remove("192.168.0.0 - 192.168.255.255, ");
                }
                break;
            case R.id.question1CheckBox2:
                if (checked) {
                    question1Selection.add("172.16.0.0 - 172.31.255.255, ");
                    checkbox2 = true;
                } else {
                    question1Selection.remove("172.16.0.0 - 172.31.255.255, ");
                }
                break;
            case R.id.question1CheckBox3:
                if (checked) {
                    question1Selection.add("169.1.0.0 - 169.1.255.255");
                } else {
                    question1Selection.remove("169.1.0.0 - 169.1.255.255");
                }
                break;
        }

        for (String Selections : question1Selection) {
            question1SelectedText = question1SelectedText + Selections + " ";
        }*/

        //coding to increment the quiz grading if the user selection is correct
       /* if (checkbox1 && checkbox2 == true) {
            score = score + 1;
        }*/


        CheckBox q1_cb1 = (CheckBox) findViewById(R.id.question1CheckBox1);
        CheckBox q1_cb2 = (CheckBox) findViewById(R.id.question1CheckBox2);
        CheckBox q1_cb3 = (CheckBox) findViewById(R.id.question1CheckBox3);

        if (q1_cb1.isChecked() && q1_cb2.isChecked() && !q1_cb3.isChecked())
     // if (((CheckBox) findViewById(R.id.question1CheckBox1)).isChecked() && ((CheckBox) findViewById(R.id.question1CheckBox2)).isChecked() &&  !((CheckBox) findViewById(R.id.question1CheckBox3)).isChecked())
        {
            score = score + 1;
        }

    }

    /**
     * This method is called when the Review button is clicked
     */
    public void reviewQuiz(View view) {

        textName = (EditText) findViewById(R.id.inputName);
        name = textName.getText().toString();

        question2Selection();
        question3Selection();
        question4Selection();
        question5Selection();
        question6Selection();
        question7Selection();

        //coding for Toast
        String myToast = "You scored " + score + " out of 7";
        Toast.makeText(getApplicationContext(), myToast, Toast.LENGTH_LONG).show();

        results = "Your Name: " + name;
        results += "\nYou scored " + score + " out of 7";
        results += "\n";
        results += "\nYou responded to the quiz questions as follows";
        results += "\n";
        results += "\n1. Select all Private IP ranges below: " + question1SelectedText;
        results += "\n";
        results += "\n2. NAT stands for: " + "\n" + question2SelectedText;
        results += "\n";
        results += "\n3. What is the port number of HTTP? " + question3SelectedText;
        results += "\n";
        results += "\n4. 10Base5, 10Base2, 10BaseT are the types of? " + question4SelectedText;
        results += "\n";
        results += "\n5. Which of the following is a loop back IP? " + question5SelectedText;
        results += "\n";
        results += "\n6. What is the size of an IPv4 address? " + question6SelectedText;
        results += "\n";
        results += "\n7. LAN stands for: " + inputLAN;
        results += "\n";

        //coding for starting Main3Activity when the Review Quiz button is clicked
        Intent startNewActivity = new Intent(this, Main3Activity.class);
        startNewActivity.putExtra("key", results);
        startNewActivity.putExtra("key2", score);
        startActivity(startNewActivity);
    }

    private void question2Selection() {
        RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.question2RadioGroup);
        question2RadioButtonID = radioGroup2.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup2.findViewById(question2RadioButtonID);
        question2SelectedText = (String) radioButton.getText();

        //coding to increment the quiz grading if the user selection is correct
        if (question2RadioButtonID == R.id.question2RadioButton3) {
            score = score + 1;
        }
    }

    private void question3Selection() {
        RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.question3RadioGroup);
        question3RadioButtonID = radioGroup3.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup3.findViewById(question3RadioButtonID);
        question3SelectedText = (String) radioButton.getText();

        //coding to increment the quiz grading if the user selection is correct
        if (question3RadioButtonID == R.id.question3RadioButton3) {
            score = score + 1;
        }
    }

    private void question4Selection() {
        RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.question4RadioGroup);
        question4RadioButtonID = radioGroup4.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup4.findViewById(question4RadioButtonID);
        question4SelectedText = (String) radioButton.getText();

        //coding to increment the quiz grading if the user selection is correct
        if (question4RadioButtonID == R.id.question4RadioButton3) {
            score = score + 1;
        }
    }

    private void question5Selection() {
        RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.question5RadioGroup);
        question5RadioButtonID = radioGroup5.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup5.findViewById(question5RadioButtonID);
        question5SelectedText = (String) radioButton.getText();

        //coding to increment the quiz grading if the user selection is correct
        if (question5RadioButtonID == R.id.question5RadioButton3) {
            score = score + 1;
        }
    }

    private void question6Selection() {
        RadioGroup radioGroup6 = (RadioGroup) findViewById(R.id.question6RadioGroup);
        question6RadioButtonID = radioGroup6.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) radioGroup6.findViewById(question6RadioButtonID);
        question6SelectedText = (String) radioButton.getText();

        //coding to increment the quiz grading if the user selection is correct
        if (question6RadioButtonID == R.id.question6RadioButton3) {
            score = score + 1;
        }
    }

    private void question7Selection() {
        textLAN = (EditText) findViewById(R.id.inputQuestion7);
        inputLAN = textLAN.getText().toString();
        inputLAN = inputLAN.toLowerCase();

        //coding to increment the quiz grading if the user selection is correct
        if (inputLAN.equals(LAN)) {
            score = score + 1;
        }
    }
}
